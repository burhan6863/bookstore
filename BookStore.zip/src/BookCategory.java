package bookstore;

public class BookCategory {
    public String code;
    public String category;

    public BookCategory(String code, String category) {
        this.code = code;
        this.category = category;
    }


}